const DEFAULTS = { enabled: true, type: "sakura", count: 45, speed: 1 };
const $ = (id) => document.getElementById(id);

function render(s) {
  $("enabled").checked = s.enabled;
  $("type").value = s.type;
  $("count").value = s.count;
  $("speed").value = s.speed;
  $("countVal").textContent = s.count;
  $("speedVal").textContent = Number(s.speed).toFixed(1) + "x";
}

function save() {
  const s = {
    enabled: $("enabled").checked,
    type: $("type").value,
    count: Number($("count").value),
    speed: Number($("speed").value)
  };
  render(s);
  chrome.storage.sync.set(s);
}

chrome.storage.sync.get(DEFAULTS, render);
["enabled", "type", "count", "speed"].forEach((id) => $(id).addEventListener("input", save));
$("reset").addEventListener("click", () => {
  chrome.storage.sync.set(DEFAULTS);
  render(DEFAULTS);
});
