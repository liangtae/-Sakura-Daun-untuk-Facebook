(() => {
  if (window.__sakuraLoaded) return;
  window.__sakuraLoaded = true;

  if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

  const DEFAULTS = { enabled: true, type: "sakura", count: 45, speed: 1 };
  let settings = { ...DEFAULTS };

  const canvas = document.createElement("canvas");
  canvas.id = "sakura-overlay";
  Object.assign(canvas.style, {
    position: "fixed",
    inset: "0",
    width: "100vw",
    height: "100vh",
    pointerEvents: "none",
    zIndex: "2147483647"
  });
  document.documentElement.appendChild(canvas);
  const ctx = canvas.getContext("2d");

  let W, H, dpr;
  function resize() {
    dpr = window.devicePixelRatio || 1;
    W = window.innerWidth;
    H = window.innerHeight;
    canvas.width = W * dpr;
    canvas.height = H * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();
  window.addEventListener("resize", resize);

  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

  // Palet warna per jenis: [warna terang, warna gelap]
  const PALETTES = {
    sakura: [["#ffe4ec", "#ffb7c9"], ["#ffd1dc", "#ff9ab5"], ["#fff0f4", "#ffc2d1"]],
    autumn: [["#ff9f43", "#d35400"], ["#ff6b4a", "#a8281a"], ["#ffd34e", "#e08e0b"], ["#c98b4b", "#7a4a1e"]],
    spring: [["#b8e986", "#4caf50"], ["#d4f1a0", "#7cb342"], ["#9be07a", "#2e8b3d"], ["#c5e8a0", "#5fa83a"]]
  };

  // Bentuk daun maple (setengah sisi kanan, dicerminkan saat digambar)
  const MAPLE_HALF = [
    [0, 0.65], [0.1, 0.2], [0.55, 0.35], [0.42, 0.0], [0.9, -0.1],
    [0.6, -0.32], [0.72, -0.7], [0.32, -0.5], [0.2, -0.9], [0, -1]
  ];

  function assignStyle(p) {
    let kind = settings.type;
    if (kind === "mix") kind = pick(["sakura", "autumn", "spring"]);
    p.kind = kind;
    p.color = pick(PALETTES[kind]);
    if (kind === "sakura") {
      p.shape = "petal";
      p.size = rand(8, 16);
    } else if (kind === "autumn") {
      p.shape = Math.random() < 0.6 ? "maple" : "leaf";
      p.size = rand(10, 18);
    } else {
      p.shape = "leaf";
      p.size = rand(9, 16);
    }
  }

  function createPetal(initial = false) {
    const p = {
      x: rand(0, W),
      y: initial ? rand(-H, H) : rand(-60, -10),
      vy: rand(0.6, 1.6),
      sway: rand(0.5, 1.5),
      swayPhase: rand(0, Math.PI * 2),
      swaySpeed: rand(0.008, 0.02),
      angle: rand(0, Math.PI * 2),
      spin: rand(-0.03, 0.03),
      flip: rand(0, Math.PI * 2),
      flipSpeed: rand(0.02, 0.05),
      opacity: rand(0.7, 0.97)
    };
    assignStyle(p);
    return p;
  }

  let petals = [];
  function syncCount() {
    while (petals.length < settings.count) petals.push(createPetal(true));
    if (petals.length > settings.count) petals.length = settings.count;
  }

  function pathPetal(s) {
    ctx.beginPath();
    ctx.moveTo(0, s);
    ctx.bezierCurveTo(s * 0.9, s * 0.5, s * 0.8, -s * 0.7, s * 0.15, -s);
    ctx.lineTo(0, -s * 0.75);
    ctx.lineTo(-s * 0.15, -s);
    ctx.bezierCurveTo(-s * 0.8, -s * 0.7, -s * 0.9, s * 0.5, 0, s);
    ctx.closePath();
  }

  function pathLeaf(s) {
    ctx.beginPath();
    ctx.moveTo(0, s);
    ctx.bezierCurveTo(s * 0.95, s * 0.3, s * 0.7, -s * 0.7, 0, -s);
    ctx.bezierCurveTo(-s * 0.7, -s * 0.7, -s * 0.95, s * 0.3, 0, s);
    ctx.closePath();
  }

  function pathMaple(s) {
    ctx.beginPath();
    ctx.moveTo(0, MAPLE_HALF[0][1] * s);
    for (let i = 1; i < MAPLE_HALF.length; i++) {
      ctx.lineTo(MAPLE_HALF[i][0] * s, MAPLE_HALF[i][1] * s);
    }
    for (let i = MAPLE_HALF.length - 2; i >= 1; i--) {
      ctx.lineTo(-MAPLE_HALF[i][0] * s, MAPLE_HALF[i][1] * s);
    }
    ctx.closePath();
  }

  function drawPetal(p) {
    const s = p.size;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);
    ctx.scale(1, Math.abs(Math.cos(p.flip)) * 0.7 + 0.3);
    ctx.globalAlpha = p.opacity;

    const g = ctx.createLinearGradient(0, -s, 0, s);
    g.addColorStop(0, p.color[0]);
    g.addColorStop(1, p.color[1]);
    ctx.fillStyle = g;

    if (p.shape === "petal") {
      pathPetal(s);
      ctx.fill();
    } else if (p.shape === "maple") {
      pathMaple(s);
      ctx.fill();
      ctx.strokeStyle = "rgba(90,30,10,0.35)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, s * 1.05);
      ctx.lineTo(0, -s * 0.6);
      ctx.stroke();
    } else {
      pathLeaf(s);
      ctx.fill();
      ctx.strokeStyle = p.kind === "spring" ? "rgba(0,60,0,0.35)" : "rgba(90,30,10,0.35)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, s * 1.15);
      ctx.lineTo(0, -s * 0.85);
      ctx.stroke();
    }
    ctx.restore();
  }

  let looping = false;
  function shouldRun() {
    return settings.enabled && !document.hidden;
  }

  function loop() {
    if (!shouldRun()) {
      looping = false;
      ctx.clearRect(0, 0, W, H);
      return;
    }
    ctx.clearRect(0, 0, W, H);
    const sp = settings.speed;
    for (let i = 0; i < petals.length; i++) {
      const p = petals[i];
      p.swayPhase += p.swaySpeed * sp;
      p.x += Math.sin(p.swayPhase) * p.sway * sp + 0.4 * sp;
      p.y += p.vy * sp;
      p.angle += p.spin * sp;
      p.flip += p.flipSpeed * sp;

      if (p.y > H + 30 || p.x > W + 40 || p.x < -40) {
        petals[i] = createPetal();
        petals[i].x = rand(-40, W);
      }
      drawPetal(p);
    }
    requestAnimationFrame(loop);
  }

  function start() {
    if (looping || !shouldRun()) return;
    looping = true;
    requestAnimationFrame(loop);
  }

  document.addEventListener("visibilitychange", start);

  function applySettings(s) {
    const typeChanged = s.type !== settings.type;
    settings = { ...DEFAULTS, ...s };
    if (typeChanged) petals.forEach(assignStyle); // ganti jenis tanpa mengubah posisi
    syncCount();
    if (!settings.enabled) ctx.clearRect(0, 0, W, H);
    start();
  }

  try {
    chrome.storage.sync.get(DEFAULTS, applySettings);
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "sync") return;
      const next = { ...settings };
      for (const k in changes) next[k] = changes[k].newValue;
      applySettings(next);
    });
  } catch (e) {
    applySettings(DEFAULTS);
  }
})();
